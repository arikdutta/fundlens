"""FundLens — a tiny Python client + analytics toolkit for Indian mutual fund data.

Data source: MFApi.in (https://www.mfapi.in) — a free, open REST API for Indian
mutual fund NAV history and scheme metadata. No authentication or API key required.

Basic usage
-----------
    >>> from fundlens import FundClient
    >>> client = FundClient()
    >>> results = client.search("HDFC Flexi Cap")
    >>> scheme = client.get_scheme(results[0].scheme_code)
    >>> nav_df = scheme.nav_history()          # pandas DataFrame
    >>> scheme.returns()                        # trailing return summary
    >>> scheme.volatility()                     # annualized volatility

The client only depends on `requests`. Analytics helpers additionally use
`pandas` and `numpy`, imported lazily so the core client stays lightweight.
"""

from .client import FundClient
from .models import Scheme, SchemeMeta, SearchResult, NavPoint
from .exceptions import (
    FundLensError,
    SchemeNotFoundError,
    APIError,
    RateLimitError,
)

__version__ = "0.1.0"

__all__ = [
    "FundClient",
    "Scheme",
    "SchemeMeta",
    "SearchResult",
    "NavPoint",
    "FundLensError",
    "SchemeNotFoundError",
    "APIError",
    "RateLimitError",
    "__version__",
]
